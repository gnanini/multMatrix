# multMatrix
Multiplicando matrizes utilizando multithread em C
